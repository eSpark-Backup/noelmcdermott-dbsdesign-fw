/*
This program made by https://controlduino.com/ runs on an arduino UNO, MEGA and others, 
Target:
The aim of this program is to measure the (%O2, Lambda, AFR, rpm) data of a gas coming from the combustion obtained from the 
lambda module (Controlduino 01M21V00) and display it on the serial monitor of the arduino.also sends battery voltage, state, 
and diagnostics.

Adjust when a "1" is sent from the arduino serial monitor. This allows the air to be set to 20.95% oxygen, to compensate for probe and components errors, and pressure due to geodetic altitude..... 

This adjustment is fixed in the non-volatile memory of the module, so it will only be adjusted the first time the set is used, if the lambda probe is changed, if the module is changed, 
or if it is observed that the air measurement differs a lot from 20.95% oxygen. This adjustment should be made when in measuring state, and with the probe in clean air the oxygen, 
lambda or AFR output value is stabilised.

Hardware required to use this software:
• Arduino board
• Lambda module and wires.(Controlduino 01M21V00)
• Wideband lambda probe
• Power supply (V=12v, I>=3A)
On the website https://controlduino.com/ you can find all the information about the lambda modules and Shield and other modules. 
Library:
To use this software you need to have installed the "Lambda_rpm" library which can be downloaded at: 
https://controlduino.com/lambda-rpm-module-01m21v00/ or https://controlduino.com/download/library-lambda_rpm-h-for-arduino/
Purchase:
In the store https://controlduino.com/store/ you can purchase, lambda shields and lambda modules, sensors, and other modules. 
Downloads:
In the following link you can download all the arduino files, smartphone APPs, data sheets about the board, and probes... : 
https://controlduino.com/lambda-rpm-module-01m21v00/
Forum:
If you have any questions or want to share your projects you can do it in the forum: https://controlduino.com/forum/

Enjoy        
*/



#include "Arduino.h"
#include <Lambda_rpm.h>

#define Lambda_SPI_NSS 2////assign to pin 2 SPI select slave ////asigno al pin 2 SPI select slave 
Lambda_rpm lambda1(Lambda_SPI_NSS);////assign to pin 2 SPI select slave ////asigno al pin 2 SPI select slave 

void setup() {
  Serial.begin(57600); ///Establish UART_USB communication with the arduino IDE//Establezco comunicacion UART_USB con la IDE de arduino    
  lambda1.SPIbeginsettings (500000);//Sets up SPI communications with the lambda sensor module(long int bauds)  //Establece comunicaciones SPI con el modulo de sonda lambda a una velocidad de (long int bauds)
  lambda1.begin();//Turn on the lambda module, it will take a while as it has to warm up.  //Enciende placa lambda, tardara un rato puesto que tiene que calentarse
  lambda1.rpmBegin();//Enables the rpm measurement of the module.
}
void loop() {

  lambda1.transmission(); //Communicate with lambda_rpm module, exchange message on SPI, with information //Comunico con modulo lambda_rpm, intercambio un mensaje en SPI, con informacion
  
  // Read values
  String State_value=lambda1.stateTextRead();//State of the lambda probe
  float  VbatValue=lambda1.vbatteryRead();//V battery
  float  O2Value=lambda1.O2Read();//%O2
  float  LambdaValue=lambda1.lambdaRead ();//Lambda
  float  AFRValue=lambda1.afrGasolineRead ();//AFR
  int rpmValue=lambda1.rpmRead();//RPM
  
  // Print values
  
  /*State of the lambda probe, Estado de la sonda lambda*/
  Serial.print("\t");  
  Serial.print(" Estate: ");
  Serial.print(State_value);
  Serial.print("\t");  

  /*%O2*/
  Serial.print(" %O2: ");
  if (lambda1.validO2Read()!=true){//verify that the O2 sensor measurement is valid.//Compruebo que la medición del sensor de O2 es válida.
      Serial.print(O2Value,2);
    }else{
      Serial.print("------");
  }

  /*lambda*/
    Serial.print("\t");  
    Serial.print(" Lambda: ");
  if (lambda1.validO2Read()!=true){//verify that the O2 sensor measurement is valid.//Compruebo que la medición del sensor de O2 es válida.
      Serial.print(LambdaValue,3);
    }else{
      Serial.print("------");
  }
    Serial.print("\t");
    
  /*AFR*/
    Serial.print(" AFR Petrol: ");
  if (lambda1.validO2Read()!=true){//verify that the O2 sensor measurement is valid.//Compruebo que la medición del sensor de O2 es válida.
    Serial.print(AFRValue,2);
  }else{
    Serial.print("------");
  }
  
  /*RPM*/
  Serial.print("\t");
  Serial.print(" rpm: ");
  Serial.print(rpmValue);  
  Serial.print("\t");
  
  /*battery voltage, tension en bateria*/
  Serial.print(" Vbat[V]: ");  
  Serial.print(VbatValue,1); 
  Serial.print("\t");  
  
  Serial.print("\n\r"); 

  //MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
  //MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
  //ADJUST WHEN A MESSAGE ARRIVES FROM THE SERIAL COMMUNICATION, IT CAN BE WRITTEN TO THE SERIAL MONITOR OF THE ARDUINO IDE.
  //Gain_adjust//
  int MensajeRecibido2;
  while(Serial.available()>2){ MensajeRecibido2=Serial.read();}//delete accumulated messages//Limpio todos los mensajes menos el ultimo es lo mejor
  if(Serial.available()>0){
    MensajeRecibido2=Serial.read();
    if (MensajeRecibido2==49){lambda1.adjustAir();Serial.print("\n\r");Serial.print("adjust");Serial.print("\n\r");}//If a message arrives by serial communication with the value 49 or "1" I adjust to compensate for errors. //Si llega un mensaje por comunicacion serie con el valor 49 o "1" ajusto para compensar errores 
   
  }
  
  //MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
  //MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM   

  delay (100);////Delay a time to limit the received data to the desired value.//Retraso un tiempo para limitar los datos recibidos, al valor desesado

}
