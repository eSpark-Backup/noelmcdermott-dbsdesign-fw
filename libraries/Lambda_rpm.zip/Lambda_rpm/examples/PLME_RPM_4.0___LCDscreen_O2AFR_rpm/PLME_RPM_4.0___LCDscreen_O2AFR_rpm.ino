
/*
This program made by https://controlduino.com/ runs on an arduino UNO, MEGA and others, 
Target:

The aim of this program is to measure the (%O2,AFR, rpm) data of a gas coming from the combustion obtained from the 
lambda module (Controlduino 01M21V00) and display it on a the display LCD, 
also shows the state you will be in when the measurement is invalid.


Hardware required to use this software:
  •  Arduino board
  • Lambda module and wires.(Controlduino 01M11V00)
  • Wideband lambda probe
  • Display (LCD1602) with (LCD I2C( controller) 
  • Power supply (V=12v, I>=2A)
  
On the website https://controlduino.com/ you can find all the information about the lambda modules and Shield and other modules. 
Library:
To use this software you need to have installed the "Lambda_rpm" library which can be downloaded at: 
https://controlduino.com/lambda-rpm-module-01m21v00/ or https://controlduino.com/download/library-lambda_rpm-h-for-arduino/
Purchase:
In the store https://controlduino.com/store/ you can purchase, lambda shields and lambda modules, sensors, and other modules. 
Downloads:
In the following link you can download all the arduino files, smartphone APPs, data sheets about the board, and probes... : 
https://controlduino.com/lambda-rpm-module-01m21v00/
Forum:
If you have any questions or want to share your projects you can do it in the forum: https://controlduino.com/forum/

Enjoy        
*/



#include "Arduino.h"
#include <LiquidCrystal_I2C.h>
#include <Lambda_rpm.h>

#define Lambda_SPI_NSS 2////assign to pin 2 SPI select slave ////asigno al pin 2 SPI select slave 
Lambda_rpm  lambda1(Lambda_SPI_NSS);////assign to pin 2 SPI select slave ////asigno al pin 2 SPI select slave
LiquidCrystal_I2C lcd(0x27, 16, 2);  // Inicia el LCD en la dirección 0x27, con 16 caracteres y 2 líneas 
#define mask_ok 0xF3E0
#define val_ok 0x00A0


void setup() {

//Lambda module  
  lambda1.SPIbeginsettings (500000);//Sets up SPI communications with the lambda sensor module(long int bauds)  //Establece comunicaciones SPI con el modulo de sonda lambda a una velocidad de (long int bauds)
  lambda1.begin();//Turn on the lambda module, it will take a while as it has to warm up.  //Enciende placa lambda, tardara un rato puesto que tiene que calentarse
  lambda1.rpmBegin(); 

//Display    
  lcd.begin();  
  lcd.clear();                    
  lcd.backlight();   
  lcd.setCursor(0, 0);
  lcd.print(" Starting  "); 
  delay(1000);
}

void loop() {
    
  lambda1.transmission();//Communicate with lambda probe, exchange message on SPI, with information //Comunico con la sonda lambda, intercambio un mensaje en SPI, con informacion  
  
// Read values
  float  AFRValue=lambda1.afrGasolineRead ();//read the AFR value if the fuel is gasoline//Leo el valor de AFR si el combustible es gasolina
  float  O2Value=lambda1.O2Read();//Read the value of the information packet sent by the SPI, scale it, and perform calculations if necessary. I get it in a floating point variable.//Leo el valor del paquete de informacion enviado por el SPI, modifico su escala, y realizo calculos si procede. lo obtengo en una variable de coma flotante.
  int rpmValue=lambda1.rpmRead();
   


// Print values
//  MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
  if(int(lambda1._chiplambda_MensajeRecibido._word4&mask_ok)==val_ok){ 
    if(lambda1.stateRead()==1){
          
      lcd.setCursor(0, 0);

        lcd.print(" %O2    ");
        lcd.print("     ");   

      lcd.setCursor(12, 0);
      lcd.print("RPM  ");
      lcd.print("   ");
      lcd.setCursor(0, 1);
      lcd.print(" ");
      
        #if 1
              
          if(O2Value>=0){//No tiene signo luego dejo espacio extra
            //lcd.print(" ");//Dejo espacio que en otro caso es para el signo
              if(O2Value>=10){
              lcd.print(O2Value,2);
              //lcd.print(" ");
            }else{
              lcd.print(" ");//Dejo espacio que en otro caso es para el signo de decena en blanco
              lcd.print(O2Value,2);
            }
          
          }else{// tiene signo luego no dejo espacio extra
            lcd.setCursor(0, 1);
            if(O2Value<=-10){
              lcd.print(O2Value,2);
              //lcd.print(" ");
            }else{
              lcd.print(" ");//Dejo espacio que en otro caso es para el signo de decena en blanco
              lcd.print(O2Value,2);  
            }
          }
          lcd.print("   ");//Limpio parte final de linea
 
        #endif
      
      lcd.print("   ");
      lcd.setCursor(10, 1);
      if(rpmValue>=10000){
      }else if(rpmValue>=1000){lcd.print(" ");
      }else if(rpmValue>=100){lcd.print("  ");
      }else if(rpmValue>=10){lcd.print("   ");}else{lcd.print("    ");}
      lcd.print(rpmValue);
      lcd.print("    ");
             
    
    }else{
  
      lcd.setCursor(0, 0);
      lcd.print("State      ");
      lcd.setCursor(12, 0);
      lcd.print("RPM   ");;
      
      lcd.setCursor(0, 1);
      lcd.print(lambda1.stateTextRead());
      //lcd.print("                ");
      
      lcd.print("      ");
      lcd.setCursor(10, 1);
      if(rpmValue>=10000){
      }else if(rpmValue>=1000){lcd.print(" ");
      }else if(rpmValue>=100){lcd.print("  ");
      }else if(rpmValue>=10){lcd.print("   ");}else{lcd.print("    ");}
      lcd.print(rpmValue);
      lcd.print("    ");
  
    }
  
  }else{
    lcd.setCursor(0, 0);
    lcd.print("State ");
    lcd.print("          ");
    
    lcd.setCursor(0, 1);
    lcd.print("SPI fault M     ");    
    //lcd.print("E_MMC");
  }
//MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM


// delay  
 delay(300);
}
