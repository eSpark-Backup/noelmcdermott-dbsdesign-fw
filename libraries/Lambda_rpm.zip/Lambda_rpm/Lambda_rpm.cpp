﻿/*
  Controlduino-01M00V00.cpp - Library for the control and calculation of the lambda module "Controlduino-01M00V00".
  Created by JMI, april 1, 2021.
  Released into the public domain.
*/

/*Define included headers.*/
#include "Arduino.h" 
#include <SPI.h>
#include "Lambda_rpm.h"

//Constructor, Select Slave 
Lambda_rpm::Lambda_rpm(int NSS_PIN)
{
  pinMode(NSS_PIN, OUTPUT);
  _NSS_PIN = NSS_PIN;   
digitalWrite(_NSS_PIN, HIGH);
 
}


/*Function*/

/*Function for transfering SPI data^.*/
void Lambda_rpm::transmission() {
  	digitalWrite(_NSS_PIN, LOW);
	buildMessage ();
delayMicroseconds(10);//150
_chiplambda_MensajeEnviado._word0=_chiplambda_MensajeRecibido._word0;
_chiplambda_MensajeEnviado._word1=_chiplambda_MensajeRecibido._word1;
_chiplambda_MensajeEnviado._word2=_chiplambda_MensajeRecibido._word2;
_chiplambda_MensajeEnviado._word3=_chiplambda_MensajeRecibido._word3;
_chiplambda_MensajeEnviado._byte8=_chiplambda_MensajeRecibido._byte8;
_chiplambda_MensajeEnviado._COMPSPI=0b101;//
_chiplambda_MensajeEnviado._SPI_ERROR_12=0b00;//
_chiplambda_MensajeEnviado._word5=_chiplambda_MensajeRecibido._word5;   
_chiplambda_MensajeEnviado._word8=_chiplambda_MensajeRecibido._word8; 
//_chiplambda_MensajeEnviado._rpm=(_chiplambda_MensajeRecibido._rpm&0xFFF0|Var_SPImensaje_rpm_ON);  
_chiplambda_MensajeEnviado._rpm=(_chiplambda_MensajeRecibido._rpm);  
_chiplambda_MensajeEnviado._rpm_ON=(Var_SPImensaje_rpm_ON);
_chiplambda_MensajeEnviado._rpm_not_usedB=(ok_MensajeEnviadoRebote);
_chiplambda_MensajeEnviado._rpm_not_usedB=(ok_MensajeEnviado);
//_chiplambda_MensajeEnviado._word6=0x3342;
//_chiplambda_MensajeEnviado._word6=0x2802;

    		SPI.beginTransaction(SPISettings(SPIBauds, MSBFIRST, SPI_MODE1));//EStaba en 1

     _chiplambda_MensajeRecibido._word0 = SPI.transfer16(_chiplambda_MensajeEnviado._word0);
      _chiplambda_MensajeRecibido._word1 = SPI.transfer16(_chiplambda_MensajeEnviado._word1);
        _chiplambda_MensajeRecibido._word2 = SPI.transfer16(_chiplambda_MensajeEnviado._word2);
          _chiplambda_MensajeRecibido._word3 = SPI.transfer16(_chiplambda_MensajeEnviado._word3);
            _chiplambda_MensajeRecibido._word4 = SPI.transfer16(_chiplambda_MensajeEnviado._word4);
              _chiplambda_MensajeRecibido._word5 = SPI.transfer16(_chiplambda_MensajeEnviado._word5);
                _chiplambda_MensajeRecibido._word6 = SPI.transfer16(_chiplambda_MensajeEnviado._word6);
                  _chiplambda_MensajeRecibido._word7 = SPI.transfer16(_chiplambda_MensajeEnviado._word7);
		    _chiplambda_MensajeRecibido._word8 = SPI.transfer16(_chiplambda_MensajeEnviado._word8);
		      _chiplambda_MensajeRecibido._word9 = SPI.transfer16(_chiplambda_MensajeEnviado._word9);



 	delayMicroseconds(150);
 	SPI.endTransaction(); 
 	delayMicroseconds(150);  
  	digitalWrite(_NSS_PIN, HIGH); 
}


/*On/Off functions*/
void Lambda_rpm::begin() {
	#define SPImensaje_ON 0b11 
	_chiplambda_MensajeEnviado._ONN=SPImensaje_ON;
	transmission();
}
void Lambda_rpm::end() {
	#define SPImensaje_OFF 0b00;
  	_chiplambda_MensajeEnviado._ONN=SPImensaje_OFF;
	transmission();
}

float Lambda_rpm::O2Read (){
  	#define O2_factor (float)0.000824625933278669
return (float)(((float)_chiplambda_MensajeRecibido._O2frac_signed)*O2_factor);
}
float Lambda_rpm::lambdaRead (){
	#define lambda_factor (float)0.0000686655985351339000000
return (float)((unsigned int)(_chiplambda_MensajeRecibido._Lambdafrac_unsigned_64)*lambda_factor); 
}
float Lambda_rpm::afrGenericRead (float Val_AFRstoichiometricGeneric ){
	#define afrGeneric_factor (float)0.0000686655985351339000000//Modificar
return (float)((unsigned int)(_chiplambda_MensajeRecibido._Lambdafrac_unsigned_64)*Val_AFRstoichiometricGeneric*afrGeneric_factor); 
}
float Lambda_rpm::afrGasolineRead (){  
  	#define AFRGasoline_factor (float)0.00100938429846647 //gasoline petrol 
return (float)((unsigned int)(_chiplambda_MensajeRecibido._Lambdafrac_unsigned_64)*AFRGasoline_factor); 
}
float Lambda_rpm::afrGasoilRead (){  
  	#define AFRGasoil_factor (float)0.000995651178759441 //diesel,gasoil
return (float)((unsigned int)(_chiplambda_MensajeRecibido._Lambdafrac_unsigned_64)*AFRGasoil_factor); 
}


float Lambda_rpm::vbatteryRead(){
  	#define VBattery_factor (float)0.000839246207318303
return ((unsigned int)_chiplambda_MensajeRecibido._VBattery_frac_unsigned_55*VBattery_factor);
}


 bool Lambda_rpm::validO2Read() {
//Añadir condicion de mensaje que llego del modulo sea válido
  //Compruebo que la medida de O2 sea valida y la comunicacion funcione, es decir que el SPI_ERROR Del mensaje de out sea el adecuado, esto lo comprobare al leer
if(_chiplambda_MensajeRecibido._VAL_MEASURING_O2==1){return true;}else{return false;}
}

 bool Lambda_rpm::validRead() {
//Añadir condicion de mensaje que llego del modulo sea válido
  //Compruebo que el mensaje sea valido o y la comunicacion funcione
if(_chiplambda_MensajeRecibido._FLAG_State_Error==1){return true;}else{return false;}//el uno era que no hay error y es valido, falta comprobar el SPI que comunique bien con el modulo
}
 int Lambda_rpm::counterModuleRead() {
return _chiplambda_MensajeRecibido._Count_Module;
}
 int Lambda_rpm::counterSampleRead() {
return _chiplambda_MensajeRecibido._Count_100hz;
}


int Lambda_rpm::stateRead(){
return _chiplambda_MensajeRecibido._State;  
}
String Lambda_rpm::stateTextRead(){
  String stateTXT;
 switch(_chiplambda_MensajeRecibido._State){
          case 0:
                    stateTXT=" Unknown 0";
    break;
          case 1:
                    stateTXT="Measuring";
    break;
          case 2:
                    stateTXT="OFF";
    break;
          case  3:
                    stateTXT="ERROR";
    break;
          case  4:
                    stateTXT="Drying";
    break;
          case  5:
                    stateTXT="Heating";
    break;
          case  6:
                    stateTXT="Pre_Starting";
    break;
          case  7:
                    stateTXT="Starting";
    break;
          default:
                    stateTXT="Unknown";
    break;
 }
 return stateTXT;
}


void Lambda_rpm::compensatePressurebar(float _pressure_value_){
   	#define _pressure__factor_bar (float)20479.6875
	#define _max_P_bar (float)3.2
   	if (_pressure_value_>_max_P_bar){_pressure_value_=_max_P_bar;}
_chiplambda_MensajeEnviado._Compensation=(unsigned int)(_pressure_value_*_pressure__factor_bar);   
}
void Lambda_rpm::compensatePressurePa(float _pressure_value_){
   	#define _pressure__factor_Pa (float)0.204796875
	#define _max_P_Pa (float)320000
   if (_pressure_value_>_max_P_Pa){_pressure_value_=_max_P_Pa;}
_chiplambda_MensajeEnviado._Compensation=(unsigned int)(_pressure_value_*_pressure__factor_Pa);   
}
void Lambda_rpm::compensatePressureAtm(float _pressure_value_){
   #define _pressure__factor_Atm (float)20751.0433297496
#define _max_P_Atm (float)3.158154458
   if (_pressure_value_>_max_P_Atm){_pressure_value_=_max_P_Atm;}
_chiplambda_MensajeEnviado._Compensation=(unsigned int)(_pressure_value_*_pressure__factor_Atm);   
}
void Lambda_rpm::compensatePressurePSI(float _pressure_value_){
   #define _pressure__factor_PSI (float)1412.02474550625
#define _max_P_PSI (float)46.41207614
   if (_pressure_value_>_max_P_PSI){_pressure_value_=_max_P_PSI;}
_chiplambda_MensajeEnviado._Compensation=(unsigned int)(_pressure_value_*_pressure__factor_PSI);   
}
 
unsigned int Lambda_rpm::messageInWord(int Number){  

   switch(Number){

          case 0:
             return _chiplambda_MensajeRecibido._word0;
    break;
          case 1:
                    return _chiplambda_MensajeRecibido._word1;
    break;
          case  2:
                    return _chiplambda_MensajeRecibido._word2;
    break;
          case  3:
                    return _chiplambda_MensajeRecibido._word3;
    break;
         case  4:
                    return _chiplambda_MensajeRecibido._word4;
    break;
         case  5:
                    return _chiplambda_MensajeRecibido._word5;
    break;
          case  6:
                    return _chiplambda_MensajeRecibido._word6;
    break;
          case  7:
                    return _chiplambda_MensajeRecibido._word7;
    break;
          case  8:
                    return _chiplambda_MensajeRecibido._word8;
    break;
          case  9:
                    return _chiplambda_MensajeRecibido._word9;
    break;
          default:
                    return _chiplambda_MensajeRecibido._word0;
    break;
 }
}
unsigned int Lambda_rpm::messageOutWord(int Number){  

   switch(Number){

          case 0:
             return _chiplambda_MensajeEnviado._word0;
    break;
          case 1:
                    return _chiplambda_MensajeEnviado._word1;
    break;
          case  2:
                    return _chiplambda_MensajeEnviado._word2;
    break;
          case  3:
                    return _chiplambda_MensajeEnviado._word3;
    break;
         case  4:
                    return _chiplambda_MensajeEnviado._word4;
    break;
         case  5:
                    return _chiplambda_MensajeEnviado._word5;
    break;
          case  6:
                    return _chiplambda_MensajeEnviado._word6;
    break;
          case  7:
                    return _chiplambda_MensajeEnviado._word7;
    break;
          case  8:
                    return _chiplambda_MensajeEnviado._word8;
    break;
          case  9:
                    return _chiplambda_MensajeEnviado._word9;
    break;
          default:
                    return _chiplambda_MensajeEnviado._word0;
    break;
 }
}

String Lambda_rpm::diagnosisRead(){
  	String diagnosisTXT="";
	diagnosisTXT="";
	#define _SPI_ERROR_12_OK 0b00 
	if (_chiplambda_MensajeRecibido._SPI_ERROR_12!=_SPI_ERROR_12_OK){diagnosisTXT=diagnosisTXT+"Communication failure _SPI_ERROR_12, ";}
	#define _COMPSPI_OK 0b101 //Modificar
	if(_chiplambda_MensajeRecibido._COMPSPI!=_COMPSPI_OK){diagnosisTXT=diagnosisTXT+"Communication failure COMPSPI, ";}
	if (_chiplambda_MensajeRecibido._Flag_Disconnected_Probe==true){diagnosisTXT=diagnosisTXT+"Disconnected Probe, ";}
	if (_chiplambda_MensajeRecibido._OverHeat==true){diagnosisTXT=diagnosisTXT+"Overheat Probe, ";}
	if (_chiplambda_MensajeRecibido._UnderHeat==true){diagnosisTXT=diagnosisTXT+"Underheat Probe, ";}
	if (_chiplambda_MensajeRecibido._Low_Battery==true){diagnosisTXT=diagnosisTXT+"Low Battery, ";}
	if (_chiplambda_MensajeRecibido._High_Battery==true){diagnosisTXT=diagnosisTXT+"High Battery, ";}
	if (_chiplambda_MensajeRecibido._FLAG_State_Error==true){diagnosisTXT=diagnosisTXT+"Error in module, ";}
	if (_chiplambda_MensajeRecibido._EQUILIBRIO==true){diagnosisTXT=diagnosisTXT+"Not in equilibrium, ";}
	if (_chiplambda_MensajeRecibido._VAL_MEASURING_O2==true){diagnosisTXT=diagnosisTXT+"Invalid O2 measurement, ";}

	if (diagnosisTXT==""){diagnosisTXT="OK";}
return diagnosisTXT;
 }   




/*Configure communications*/
void Lambda_rpm::SPIbeginsettings (unsigned long int Bauds) { 
SPI.begin(14,12,13); 
	SPIBauds=Bauds;
 	digitalWrite(_NSS_PIN, HIGH); 
}
void Lambda_rpm::SPIbegin () {   
	SPI.begin(14,12,13);
}
void Lambda_rpm::SPIend () { 
	SPI.end();  
}


/*communication messages*/
void Lambda_rpm::adjustAir(){
	_requestFlag._adjustAir=1;
}
void Lambda_rpm::timeAutoOff(unsigned int timeOff){
	if (timeOff<=0x03FF){
	_timeOFFVar=timeOff;
	}else{_timeOFFVar=0x03FF;}
	_requestFlag._timeAutoOff=1;
}
void Lambda_rpm::timeAutoOffMNV(unsigned int timeOff){
	if (timeOff<=0x03FF){
	_timeOFFVarMNV=timeOff;
	}else{_timeOFFVarMNV=0x03FF;}
	_requestFlag._timeAutoOffMNV=1;
}
void Lambda_rpm::reset_L9780(){
	_requestFlag._reset_L9780=1;
}
void Lambda_rpm::reset_uC(){
	_requestFlag._reset_uC=1;
}
void Lambda_rpm::cleanErrors(){
	_requestFlag._cleanErrors=1;
}

void Lambda_rpm::FilterValue(unsigned int _FilterValue){//(0,63)
	if (_FilterValue<=0x003F){
	_FilterValueVar=_FilterValue;
	}else{_FilterValueVar=0x003F;}
	_requestFlag._FilterValue=1;
}

void Lambda_rpm::FilterValueMNV(unsigned int _FilterValue){//(0,63)
	if (_FilterValue<=0x003F){
	_FilterValueVarMNV=_FilterValue;
	}else{_FilterValueVarMNV=0x003F;}
	_requestFlag._FilterValueMNV=1;
}

void Lambda_rpm::EnableCompensaP(boolean _EnableCompensaP){
	#define CompensacionP_On 0b0011//0x3
	#define CompensacionP_Off 0x1100//0xC  
	if (_EnableCompensaP==true){
	_EnableCompensaP_Var=CompensacionP_On;
	}else{_EnableCompensaP_Var=CompensacionP_Off;}
	_requestFlag._EnableCompensaP=1;
}

void Lambda_rpm::EnableCompensaP_MNV(boolean _EnableCompensaP){
	#define CompensacionP_On 0b0011//0x3
	#define CompensacionP_Off 0x1100//0xC  
	if (_EnableCompensaP==true){
	_EnableCompensaP_VarMNV==CompensacionP_On;
	}else{_EnableCompensaP_VarMNV=CompensacionP_Off;}
	_requestFlag._EnableCompensaP_MNV=1;
}

void Lambda_rpm::requestCode(){
	_requestFlag._requestCode=1;
}

void Lambda_rpm::requestValueAdjustAir(){ 
_requestFlag._requestValueAdjustAir=1;
}

void Lambda_rpm::reset_AjustAIR(){ 
_requestFlag._reset_uC_AjustAIR=1;
}

unsigned int Lambda_rpm::readReply(){
return _chiplambda_MensajeRecibido._word6;  
}

void Lambda_rpm::rpmFilterValue(unsigned int _FilterValue){
	if (_FilterValue<=0x003F){
	_rpm_FilterValueVarMNV=_FilterValue;
	}else{_rpm_FilterValueVarMNV=0x003F;}
	_requestFlag_rpm._rpm_FilterValueMNV=1;
}
void Lambda_rpm::rpmRps(unsigned int _RpsValue){
	if (_RpsValue<=0x03FF){
	_rpm_RpsValueVarMNV=_RpsValue;
	}else{_rpm_RpsValueVarMNV=0x03FF;}
	_requestFlag_rpm._rpm_RpsValueMNV=1;
}//Numero de revoluciones por muestras del sensor

void Lambda_rpm::rpmSpr(unsigned int _SprValue){
	if (_SprValue<=0x03FF){
	_rpm_SprValueVarMNV=_SprValue;
	}else{_rpm_SprValueVarMNV=0x03FF;}
	_requestFlag_rpm._rpm_SprValueMNV=1;
}

void Lambda_rpm::rpmAddNumValues(unsigned int _AddNumValuesValue){
	if (_AddNumValuesValue<=0x003F){
	_rpm_AddNumValuesValueVarMNV=_AddNumValuesValue;
	}else{_rpm_AddNumValuesValueVarMNV=0x003F;}	
	_requestFlag_rpm._rpm_AddNumValuesValueMNV=1;
}
void Lambda_rpm::rpmMaxValue(unsigned int _MaxValue){
	_MaxValue=_MaxValue>>5;
	if (_MaxValue<=0x03FF){
	_rpm_MaxValueVarMNV=_MaxValue;
	}else{_rpm_MaxValueVarMNV=0x03FF;}

	_requestFlag_rpm._rpmMaxValueMNV=1;
}


void Lambda_rpm::rpmEscalerSamples(unsigned int _EscalerValue){
	if (_EscalerValue<=0x0005){
	_rpm_EscalerValueVarMNV=_EscalerValue;
	}else{
	_rpm_EscalerValueVarMNV=0x0005;
	}
	_requestFlag_rpm._rpm_EscalerValueMNV=1;
}

void Lambda_rpm::rpmPostEscaler(unsigned int _PostEscalerValue){
if (_PostEscalerValue<=0x03FF){
	_rpm_PostEscalerValueVarMNV=_PostEscalerValue;
	}else{_rpm_PostEscalerValueVarMNV=0x03FF;}

_requestFlag_rpm._rpmPostEscalerValueMNV=1;
}

void Lambda_rpm::rpmModulePinSelect(unsigned int _ModulePinSelectValue){//"0 or other" Shield rpm IN\\"1" Module, rpm IN
if(_ModulePinSelectValue==0x0001){
	_rpmModulePinSelectValueVarMNV=0x3436;
	}else{_rpmModulePinSelectValueVarMNV=0x3439;}

_requestFlag_rpm._rpmModulePinSelect=1;
}




void Lambda_rpm::SaveMVinMNV(){
_requestFlag_rpm._SaveMVinMNV=1;
}

void Lambda_rpm::buildMessage (){
	#define _LambdaRequest_adjust 0xF0A6
	#define _LambdaRequest_adjust_Pressure 0xF0A7
	#define _LambdaRequest_timeAutoOff 0x4800
	#define _LambdaRequest_timeAutoOffMNV 0x4400
	#define _LambdaRequest_reset_L9780 0xAAEA
	#define _LambdaRequest_reset_uC 0xA5E5
	#define _LambdaRequest_cleanErrors 0xF666//Cambiado 
	#define _LambdaRequest_Normal 0xF51F
	#define _LambdaRequest_FilterMV 0x68C0
	#define _LambdaRequest_FilterMNV 0x6740
	#define _LambdaRequest_CompensaP_MV 0x6D60
	#define _LambdaRequest_CompensaP_MNV 0x6310
	#define _LambdaRequest_requestCode 0xFF01
	#define _LambdaRequest_requestValueAdjustAir 0xF0B7
	#define _LambdaRequest_reset_uC_AjustAIR 0xA6E6

	#define _LambdaRequest_rpm_FilterValueMNV 0x3340 //10     
	#define _LambdaRequest_rpm_RpsValueMNV 0x2400 //6  
	#define _LambdaRequest_rpm_SprValueMNV 0x2800 //6      
	#define _LambdaRequest_rpm_AddNumValuesValueMNV 0x3380 //10  
	#define _LambdaRequest_rpmMaxValueMNV 0x2C00 //6  
	#define _LambdaRequest_rpm_EscalerValueMNV 0x3230 //12  
	
	#define _LambdaRequest_rpm_PostEscalerValueMNV 0x3400
	#define _LambdaRequest_rpm__SaveMVinMNV 0xF335  



	if(_requestFlag._word0!=0){

		if(_requestFlag._adjustAir==1){_requestFlag._adjustAir=0;_chiplambda_MensajeEnviado._word6=_LambdaRequest_adjust;
		}else if(_requestFlag._cleanErrors==1){
		_requestFlag._cleanErrors=0;
		_chiplambda_MensajeEnviado._word6=_LambdaRequest_cleanErrors;

		}else if(_requestFlag._requestCode==1){
		_requestFlag._requestCode=0;
		_chiplambda_MensajeEnviado._word6=_LambdaRequest_requestCode;

		}else if(_requestFlag._timeAutoOff==1){
		_requestFlag._timeAutoOff=0;
		_chiplambda_MensajeEnviado._word6=(_LambdaRequest_timeAutoOff)|( _timeOFFVar);

		}else if(_requestFlag._EnableCompensaP==1){
		_requestFlag._EnableCompensaP=0;
		_chiplambda_MensajeEnviado._word6=_LambdaRequest_CompensaP_MV|(_EnableCompensaP_Var);

		}else if(_requestFlag._FilterValue==1){
		_requestFlag._FilterValue=0;
		_chiplambda_MensajeEnviado._word6=_LambdaRequest_FilterMV|(_FilterValueVar);

		}else if(_requestFlag._timeAutoOffMNV==1){
		_requestFlag._timeAutoOffMNV=0;
		_chiplambda_MensajeEnviado._word6=_LambdaRequest_timeAutoOffMNV|(_timeOFFVarMNV);

		}else if(_requestFlag._EnableCompensaP_MNV==1){
		_requestFlag._EnableCompensaP_MNV=0;
		_chiplambda_MensajeEnviado._word6=_LambdaRequest_CompensaP_MNV|(_EnableCompensaP_VarMNV);

		}else if(_requestFlag._FilterValueMNV==1){
		_requestFlag._FilterValueMNV=0;
		_chiplambda_MensajeEnviado._word6=_LambdaRequest_FilterMNV|(_FilterValueVarMNV);

		}else if(_requestFlag._reset_L9780==1){
		_requestFlag._reset_L9780=0;
		_chiplambda_MensajeEnviado._word6=_LambdaRequest_reset_L9780;

		}else if(_requestFlag._reset_uC==1){
		_requestFlag._reset_uC=0;
		_chiplambda_MensajeEnviado._word6=_LambdaRequest_reset_uC;

		}else if (_requestFlag._requestValueAdjustAir==1){
		_requestFlag._requestValueAdjustAir=0;		
		_chiplambda_MensajeEnviado._word6=_LambdaRequest_requestValueAdjustAir;
		
		}else if (_requestFlag._reset_uC_AjustAIR==1){
		_requestFlag._reset_uC_AjustAIR=0;		
		_chiplambda_MensajeEnviado._word6=_LambdaRequest_reset_uC_AjustAIR;

		}
	}else if ((_requestFlag_rpm._word0!=0)){
	

		if(_requestFlag_rpm._rpm_FilterValueMNV==1){
		_requestFlag_rpm._rpm_FilterValueMNV=0;
		_chiplambda_MensajeEnviado._word6=_LambdaRequest_rpm_FilterValueMNV|(_rpm_FilterValueVarMNV);
Serial.print("Filter");
Serial.print(_chiplambda_MensajeEnviado._word6,HEX);
//transmission();
		
		}else if(_requestFlag_rpm._rpm_RpsValueMNV==1){
		_requestFlag_rpm._rpm_RpsValueMNV=0;
		_chiplambda_MensajeEnviado._word6=_LambdaRequest_rpm_RpsValueMNV|(_rpm_RpsValueVarMNV);
//_chiplambda_MensajeEnviado._word6=0x2404;//

//transmission();
		}else if(_requestFlag_rpm._rpm_SprValueMNV==1){
		_requestFlag_rpm._rpm_SprValueMNV=0;
		_chiplambda_MensajeEnviado._word6=_LambdaRequest_rpm_SprValueMNV|(_rpm_SprValueVarMNV);
//_chiplambda_MensajeEnviado._word6=0x2805;//
//Serial.print("_SprValue");
//Serial.print(_chiplambda_MensajeEnviado._word6,HEX);
//transmission();	



	
		}else if(_requestFlag_rpm._rpm_AddNumValuesValueMNV==1){
		_requestFlag_rpm._rpm_AddNumValuesValueMNV=0;
		_chiplambda_MensajeEnviado._word6=_LambdaRequest_rpm_AddNumValuesValueMNV|(_rpm_AddNumValuesValueVarMNV);
//transmission();
		}else if(_requestFlag_rpm._rpmMaxValueMNV==1){
		_requestFlag_rpm._rpmMaxValueMNV=0;
		_chiplambda_MensajeEnviado._word6=_LambdaRequest_rpmMaxValueMNV|(_rpm_MaxValueVarMNV);
//transmission();
		}else if(_requestFlag_rpm._rpm_EscalerValueMNV==1){
		_requestFlag_rpm._rpm_EscalerValueMNV=0;
		_chiplambda_MensajeEnviado._word6=_LambdaRequest_rpm_EscalerValueMNV|(_rpm_EscalerValueVarMNV);
//transmission();
		}else if (_requestFlag_rpm._rpmPostEscalerValueMNV==1){
		_requestFlag_rpm._rpmPostEscalerValueMNV=0;		
		_chiplambda_MensajeEnviado._word6=((_LambdaRequest_rpm_PostEscalerValueMNV)|(_rpm_PostEscalerValueVarMNV));
//transmission();
		}else if (_requestFlag_rpm._rpmModulePinSelect==1){
		_requestFlag_rpm._rpmModulePinSelect=0;		
		_chiplambda_MensajeEnviado._word6=(_rpmModulePinSelectValueVarMNV);
//transmission();		


		}else if (_requestFlag_rpm._SaveMVinMNV==1){
		_requestFlag_rpm._SaveMVinMNV=0;		
		_chiplambda_MensajeEnviado._word6=_LambdaRequest_rpm__SaveMVinMNV;
//transmission();
		}


	}else{_chiplambda_MensajeEnviado._word6=_LambdaRequest_Normal;}


}


/*On/Off RPM functions*/
void Lambda_rpm::rpmBegin() {
	#define SPImensaje_rpm_ON 0b0011 
	Var_SPImensaje_rpm_ON=SPImensaje_rpm_ON;
	transmission();
}
void Lambda_rpm::rpmEnd() {
	#define SPImensaje_rpm_OFF 0b1100
  	Var_SPImensaje_rpm_ON=SPImensaje_rpm_OFF;
	transmission();
}

int Lambda_rpm::rpmRead(){
return _chiplambda_MensajeRecibido._rpm;
}


bool Lambda_rpm::IsConectedModule(){
return(_chiplambda_MensajeRecibido._rpm_not_usedB==ok_MensajeEnviado);
} 
 

