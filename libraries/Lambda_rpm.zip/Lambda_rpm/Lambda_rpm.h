/*
  Controlduino-01M00V00.h - Library for the control and calculation of the lambda module "Controlduino-01M00V00".
  Created by Jose Manuel I, april 1, 2021.
  Released into the public domain.
*/

#ifndef Controlduino_01M11V00_h 

#define Controlduino_01M11V00_h 
#ifdef Controlduino_01M11V00_h 
/*Define included headers.*/
#include <SPI.h>
#include "Arduino.h"

class Lambda_rpm
{


  public:

typedef union{
    struct{
        //Word 0
    signed _O2frac_signed:16;

    //Word 1
    unsigned _Lambdafrac_unsigned_64:16;

    //Word 2
    unsigned _VBattery_frac_unsigned_55:16;    

    //Word 3 lsb    
    unsigned _flagsInternal1:8;
    //Word 3 msb
    unsigned _flagsInternal2:5;
    unsigned _Flag_Disconnected_Probe:1; 
    unsigned _OverHeat:1;    
    unsigned _UnderHeat:1; 
       
    //Word 4  lsb 
    unsigned _Low_Battery:1;      
    unsigned _High_Battery:1;
    unsigned _FLAG_State_Error:1;    
    unsigned _EQUILIBRIO:1;     
    unsigned _VAL_MEASURING_O2:1;
    unsigned _COMPSPI:3;   
    //Word 4 msb 
    //unsigned _SPI_ERROR_1:1;
    //unsigned _SPI_ERROR_2:1;
    unsigned _SPI_ERROR_12:2;
    unsigned _ONN:2;
    unsigned _REG:1;
    unsigned _VER:3;
     
    //Word 5 
    unsigned _State:4;   
    unsigned int _Count_Module:4;
    unsigned _Count_100hz:8;
     
    //Word 6 calibracion
    unsigned _Calibration:16;

    //Word 7 Compensacion
    unsigned _Compensation:16;

    //Word 8 rpm
    unsigned _rpm:16;

    //Word 9 rpm
    unsigned _rpm_ON:4;
    unsigned _rpm_not_usedA:4;
    unsigned _rpm_not_usedB:8;



};

    struct{
    unsigned int _byte0:8; 
    unsigned int _byte1:8;
    unsigned int _byte2:8;
    unsigned int _byte3:8;
    unsigned int _byte4:8;
    unsigned int _byte5:8;
    unsigned int _byte6:8;
    unsigned int _byte7:8;
    unsigned int _byte8:8;
    unsigned int _byte9:8;
    unsigned int _byte10:8;
    unsigned int _byte11:8;
    unsigned int _byte12:8;
    unsigned int _byte13:8;
    unsigned int _byte14:8;
    unsigned int _byte15:8;
    unsigned int _byte16:8;
    unsigned int _byte17:8;
    unsigned int _byte18:8;
    unsigned int _byte19:8;
    
};

    struct{
    unsigned int _word0:16; 
    unsigned int _word1:16;
    unsigned int _word2:16;
    unsigned int _word3:16;
    unsigned int _word4:16;
    unsigned int _word5:16;
    unsigned int _word6:16;
    unsigned int _word7:16;
    unsigned int _word8:16;
    unsigned int _word9:16;

       
};
 
}TYPE_ChipLambda_ST_L9780_arduino_SO;

TYPE_ChipLambda_ST_L9780_arduino_SO _chiplambda_MensajeEnviado;
TYPE_ChipLambda_ST_L9780_arduino_SO _chiplambda_MensajeRecibido;

/*Constructor*/
Lambda_rpm(int NSS_PIN);
/*functions*/
void begin();		
void end();

float  O2Read();		
float  lambdaRead();	
float afrGenericRead (float);
float afrGasolineRead ();
float afrGasoilRead ();	
float vbatteryRead();

String diagnosisRead();	
int  stateRead();     
String stateTextRead();
bool  validO2Read();	
bool  validRead();
int  validReadTransmission();
int counterModuleRead(); 
int counterSampleRead(); 

unsigned int messageOutWord(int Number);
unsigned int messageInWord(int Number);

void transmission();
int transmissionb();

void SPIbegin (); 
void SPIbeginsettings (unsigned long int);

void SPIend ();

void compensatePressurebar(float);
void compensatePressurePa(float);
void compensatePressureAtm(float);
void compensatePressurePSI(float);

void adjustAir();
void timeAutoOff(unsigned int);
void timeAutoOffMNV(unsigned int);
void reset_L9780();
void reset_uC();
void cleanErrors();
unsigned int readReply();
void requestCode();
void requestValueAdjustAir();
void reset_AjustAIR();

void FilterValue(unsigned int);//"0" Disable,  "1(min filter) to 63(max filter)"  , other=(max filter)
void FilterValueMNV(unsigned int);//"0" Disable,  "1(min filter) to 63(max filter)"  , other=(max filter)
void EnableCompensaP(boolean);//"0" Disable, "1" Enable, other Not valid
void EnableCompensaP_MNV(boolean);//"0" Disable, "1" Enable, other Not valid

unsigned int _FilterValueVar;//Max 0x=003F//Disable 0x0000
unsigned int _FilterValueVarMNV;//Max 0x=003F//Disable 0x0000
unsigned int _EnableCompensaP_Var;//Enable 0x000F;//Disable 0x0000
unsigned int _EnableCompensaP_VarMNV;//Enable 0x000F;//Disable 0x0000


int rpmRead();
void rpmBegin();
void rpmEnd(); 

void rpmFilterValue(unsigned int);//Max 0x=003F//Disable 0x0000
void rpmRps(unsigned int);//Numero de revoluciones por muestras del sensor
void rpmSpr(unsigned int);//Numero de muestras del sensor por cada vuelta
void rpmAddNumValues(unsigned int);//'0' calcula valor de rpm en cada interrupcion, "x"  x+1 other calcula el valor sumando los tiempos de las muestras indicadas 
void rpmMaxValue(unsigned int);// Indica el maximo numer de rpm; Igual sobra
void rpmEscalerSamples(unsigned int); //"0" 1, "1" 4, "2" 16,other 1 
void rpmPostEscaler(unsigned int);
void rpmModulePinSelect(unsigned int);

void SaveMVinMNV(); 
bool IsConectedModule(); 	

  private:

unsigned long int SPIBauds;    
int _NSS_PIN;
//TYPE_ChipLambda_ST_L9780_arduino_SO _chiplambda_MensajeEnviado;//Puedo usarlo como variable temporal si quiero cambiar todo a la vez
//TYPE_ChipLambda_ST_L9780_arduino_SO _chiplambda_MensajeRecibido;//Puedo usarlo como variable temporal si quiero cambiar todo a la vez
int _flag_calibro=0;//No se para que sirve??
void buildMessage();

#if 1

typedef union{
    struct{
    unsigned _adjustAir:1;      
    unsigned _timeAutoOff:1;
    unsigned _timeAutoOffMNV:1;    
    unsigned _reset_L9780:1;     
    unsigned _reset_uC:1;
    unsigned _cleanErrors:1;

    unsigned _FilterValue:1;    
    unsigned _FilterValueMNV:1;  
   
    unsigned _EnableCompensaP:1;
    unsigned _EnableCompensaP_MNV:1;
    unsigned _requestCode:1;
    unsigned _requestValueAdjustAir:1;
    unsigned _reset_uC_AjustAIR:1;    
    unsigned _NotUsed:3;
};
struct{
unsigned _byte0:8;
unsigned _byte1:8;
}; 
struct{
unsigned int _word0:16;
}; 
}TYPE_requestFlag;

TYPE_requestFlag _requestFlag;
//_requestFlag._word0=0;
unsigned int _timeOFFVar;//Max 0x=03FF;
unsigned int _timeOFFVarMNV;//Max 0x=03FF;
#endif
#if 1
typedef union{
    struct{
    unsigned _rpm_FilterValueMNV:1;      
    unsigned _rpm_RpsValueMNV:1;
    unsigned _rpm_SprValueMNV:1;    
    unsigned _rpm_AddNumValuesValueMNV:1;
    unsigned _rpmMaxValueMNV:1;
    unsigned _rpm_EscalerValueMNV:1;
    unsigned _rpmPostEscalerValueMNV:1;
    unsigned _rpmModulePinSelect:1;
    unsigned _SaveMVinMNV:1;
    unsigned _NotUsed:7;
};
struct{
unsigned _byte0:8;
unsigned _byte1:8;
}; 
struct{
unsigned int _word0:16;
}; 
}TYPE_requestFlag_rpm;
TYPE_requestFlag_rpm _requestFlag_rpm;

unsigned int _rpm_FilterValueVarMNV;//Max 0x=003F//Disable 0x0000
unsigned int _rpm_RpsValueVarMNV;//Max 0x=03FF;
unsigned int _rpm_SprValueVarMNV;//Max 0x=03FF;
unsigned int _rpm_AddNumValuesValueVarMNV;//Max 0x=003F;
unsigned int _rpm_MaxValueVarMNV;//Max 0x=03FF;
unsigned int _rpm_EscalerValueVarMNV;//Max 0x=0002; 0, 1 or 2;

unsigned int _rpm_PostEscalerValueVarMNV;//Max 0x=03FF;
unsigned int _rpmModulePinSelectValueVarMNV;//"1" Shield,"other" Module 
#endif

#define SPImensaje_rpm_OFF 0b1100
#define SPImensaje_rpm_ON 0b0011
unsigned int Var_SPImensaje_rpm_ON=SPImensaje_rpm_OFF;

#endif

#define ok_MensajeEnviado 0xA5
#define ok_MensajeEnviadoRebote 0xD
};


#endif



